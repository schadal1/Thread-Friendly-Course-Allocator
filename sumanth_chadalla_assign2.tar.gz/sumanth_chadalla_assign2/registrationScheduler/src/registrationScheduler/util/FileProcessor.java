package registrationScheduler.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;



public class FileProcessor {

	private  Scanner input;
	private  FileWriter output;
	private static FileProcessor uniqueInstance;
	private FileProcessor(String inputFile,String outputFile)
	{
		try {

	    	input = new Scanner(new File(inputFile));
	    	output = new FileWriter(new File(outputFile));
	    } 
	    catch (IOException e) {
	        e.printStackTrace();
	        System.exit(0);
	    }
		if(Logger.getDebugValue().equals(Logger.DebugLevel.four)){
			
			Logger.writeMessage("FileProcessor Constructor invoked",Logger.DebugLevel.four );
		}
	}
	//public FileProcessor(String inputFile,String outputFile) throws IOException
	public static  FileProcessor getInstance(String inputFile,String outputFile)
	{	
		
		if(uniqueInstance==null)
		{
			uniqueInstance=new FileProcessor(inputFile,outputFile);			
		} 
		
		return uniqueInstance;		
	}
	public synchronized String getLine()
	{
		return input.nextLine();
	}
	public synchronized boolean hasNextLine()
	{
		return input.hasNextLine();
	}
}
