package registrationScheduler.util;

public class Scheduler {
	private ObjectPool object;
	private CourseAssignor Assignor;
	
	
	public Scheduler()
	{
		object=ObjectPool.getInstance();
		Assignor=new CourseAssignor();
	}
	public synchronized Student  CreateStudent()
	{
		Student s=object.addObject();
		Student.studentCount++;
		return s;
	}
	/**
	*@param Student,Line 
	*@Return none
	*/
	public synchronized void AssignVal(Student s,String Line)
	{
		 String[] splitString=Line.split(" ");	
		 s.setName(splitString[0]);
		 s.setAPref(Integer.parseInt(splitString[1]));
		 s.setBPref(Integer.parseInt(splitString[2]));
		 s.setCPref(Integer.parseInt(splitString[3]));
		 s.setDPref(Integer.parseInt(splitString[4]));
		 s.setEPref(Integer.parseInt(splitString[5]));
		 s.setFPref(Integer.parseInt(splitString[6]));
		 s.setGPref(Integer.parseInt(splitString[7]));		
	}
	/**
	*@param Student
	*@Return none
	*/
	public synchronized void AssignCourse(Student s)
	{
		//Assignor.DirectAssign(object, s);
		Assignor.randomAssignor(object, s);
		/*if(s.studentCount<=10)
		{
			Assignor.DirectAssign(object, s);
		}
		else
		{
			Assignor.HardAssign(object,s);
		}*/
		
	}	
	
}
