package registrationScheduler.util;

public class Course {
	private String CourseName;
	private int NoOfSeats;
	private int Status;
	//This is the Course Class
	public Course(int Seats,String CourseName)
	{
		setCourseName(CourseName);
		setNoOfSeats(Seats);
		setStatus(1);
	}
	public int getNoOfSeats() {
		return NoOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		NoOfSeats = noOfSeats;
	}
	public void getAseat()
	{
		--NoOfSeats;
	}
	public  int getStatus() {
		return Status;
	}
	public  void setStatus(int status) {
		Status = status;
	}
	public  String getCourseName() {
		return CourseName;
	}
	public  void setCourseName(String course_Name) {
		CourseName = course_Name;
	}
	
}