package registrationScheduler.util;

public class Student {
	public static int studentCount=0;
	private static int AvgTotal=0;
	private String Name;
	private String[] Assigned;
	private int APref;
	private int BPref;
	private int CPref;
	private int DPref;
	private int EPref;
	private int FPref;
	private int GPref;
	private int TotalPref;
	public Student()
	{
		setAssigned(new String[5]);
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAPref() {
		return APref;
	}
	public void setAPref(int aPref) {
		APref = aPref;
	}
	public int getBPref() {
		return BPref;
	}
	public void setBPref(int bPref) {
		BPref = bPref;
	}
	public int getCPref() {
		return CPref;
	}
	public void setCPref(int cPref) {
		CPref = cPref;
	}
	public int getDPref() {
		return DPref;
	}
	public void setDPref(int dPref) {
		DPref = dPref;
	}
	public int getEPref() {
		return EPref;
	}
	public void setEPref(int ePref) {
		EPref = ePref;
	}
	public int getFPref() {
		return FPref;
	}
	public void setFPref(int fPref) {
		FPref = fPref;
	}
	public int getGPref() {
		return GPref;
	}
	public void setGPref(int gPref) {
		GPref = gPref;
	}
	public String[] getAssigned() {
		return Assigned;
	}
	public void setAssigned(String[] assigned) {
		Assigned = assigned;
	}
	public void AssignCourse(int index,String CourseName)
	{
		Assigned[index]=CourseName;
	}
	public String getAssignedCourse(int index)	
	{
		return Assigned[index];
	}
	public int getTotalPref() {
		return TotalPref;
	}
	public void setTotalPref(int totalPref) {
		TotalPref = totalPref;
	}
	public int getAvgTotal() {
		return AvgTotal;
	}
	public void setAvgTotal(int avgTotal) {
		AvgTotal = avgTotal;
	}
}
