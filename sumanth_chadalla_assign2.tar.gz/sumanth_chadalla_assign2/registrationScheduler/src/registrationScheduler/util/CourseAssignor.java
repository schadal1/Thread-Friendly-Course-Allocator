package registrationScheduler.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import registrationScheduler.util.Logger;
import registrationScheduler.util.Course;
import registrationScheduler.util.FileProcessor;
import registrationScheduler.util.Logger;
import registrationScheduler.util.ObjectPool;
import registrationScheduler.util.Scheduler;
import registrationScheduler.util.Student;
import registrationScheduler.store.StdoutDisplayInterface;
import registrationScheduler.store.FileDisplayInterface;
import registrationScheduler.store.Results;
import registrationScheduler.threadMgmt.CreateWorkers;
import registrationScheduler.threadMgmt.WorkerThread;


public class CourseAssignor {
	private int count;
	private Course[] Course;
	private ArrayList<Integer> list;
	
	/**
	*@param objectpool,student
	*@Return none 
	*/
	public void HardAssign(ObjectPool Obj,Student s)
	{
		Course=new Course[7];
		Course[0]=Obj.getA();
		Course[1]=Obj.getB();
		Course[2]=Obj.getC();
		Course[3]=Obj.getD();
		Course[4]=Obj.getE();
		Course[5]=Obj.getF();
		Course[6]=Obj.getG();
		int MaxSeatsIndex=0;
		int secondMax=0;
		int thirdMax=0;
		int fourthMax=0;
		for(int i=0;i<7;i++)
		{			
			if(Course[i].getNoOfSeats()>=Course[MaxSeatsIndex].getNoOfSeats())
			{
				MaxSeatsIndex=i;
			}			
		}
		
	}
	/**
	*@param objectpool,student
	*@Return none 
	*/
	public void DirectAssign(ObjectPool Obj,Student s)
	{
		setCount(0);
		if(s.getAPref()<=5)
		{
			Obj.borrowObject("A");
			s.AssignCourse(count,"A");
			count++;
		}
		if(s.getBPref()<=5)
		{
			Obj.borrowObject("B");
			s.AssignCourse(count,"B");
			count++;
			
		}
		if(s.getCPref()<=5)
		{
			Obj.borrowObject("C");
			s.AssignCourse(count,"C");
			count++;
			
		}
		if(s.getDPref()<=5)
		{
			Obj.borrowObject("D");
			s.AssignCourse(count,"D");
			count++;
			
		}
		if(s.getEPref()<=5)
		{
			Obj.borrowObject("E");
			s.AssignCourse(count,"E");
			count++;
			
		}
		if(s.getFPref()<=5)
		{
			Obj.borrowObject("F");
			s.AssignCourse(count,"F");
			count++;
			
		}
		if(s.getGPref()<=5)
		{
			Obj.borrowObject("G");
			s.AssignCourse(count,"G");
			count++;
			
		}
	}
	/**
	*@param objectpool,student
	*@Return none 
	*/
	public synchronized void randomAssignor(ObjectPool Obj,Student s)
	{
		Random rand = new Random();
		if(list==null)
		{
			list= new ArrayList<Integer>(7);
		}
		if(list.size()==0)
		{    	   
    	   for(int i = 1; i <= 7; i++) {
               list.add(i);
           }		
		}
        int index = rand.nextInt(list.size());
        String Order=randomOrder(list.remove(index)-1);
        setCount(0);
        int total=0,avgTotal=0;
        for(int i=0;i<Order.length();i++)
        {
        	
        	switch(Order.charAt(i))
        	{
        	case 'A':
        		Obj.borrowObject("A");
    			s.AssignCourse(count,"A");
    			total=total+s.getAPref();
    			count++;
        		break;
        	case 'B':
        		Obj.borrowObject("B");
    			s.AssignCourse(count,"B");
    			total=total+s.getBPref();
    			count++;
        		break;
        	case 'C':
        		Obj.borrowObject("C");
    			s.AssignCourse(count,"C");
    			total=total+s.getCPref();
    			count++;
        		break;
        	case 'D':
        		Obj.borrowObject("D");
    			s.AssignCourse(count,"D");
    			total=total+s.getDPref();
    			count++;
        		break;
        	case 'E':
        		Obj.borrowObject("E");
    			s.AssignCourse(count,"E");
    			total=total+s.getEPref();
    			count++;
        		break;
        	case 'F':
        		Obj.borrowObject("F");
    			s.AssignCourse(count,"F");
    			total=total+s.getFPref();
    			count++;
        		break;
        	case 'G': 
    			Obj.borrowObject("G");
    			s.AssignCourse(count,"G");
    			total=total+s.getGPref();
    			count++;
        		break;
        	default:
        		break;        	
        	}
        }
        avgTotal=s.getAvgTotal();
        avgTotal=avgTotal+total;
        s.setAvgTotal(avgTotal);
        s.setTotalPref(total);
                     
	}
	/**
	*@param randomIndex//index for getting random preference
	*@Return String//Random string orderr 
	*/
	private String randomOrder(int randomIndex)
	{			
		String line="ABCDEFG";		
		int count=5;
		
		String returnString="";
		//System.out.println(randomIndex);
		for(int i=randomIndex;i<line.length();i++)
		{
			if(count==0)
				break;
			//System.out.println(line.charAt(i));
			returnString=returnString+line.charAt(i);
			count--;
			
		}
		for(int i=0;i<randomIndex;i++)
		{
			if(count==0)
				break;
			//System.out.println(line.charAt(i));
			returnString=returnString+line.charAt(i);
			count--;
			
		}
		return returnString;
		
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}
