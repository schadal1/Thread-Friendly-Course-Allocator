
package registrationScheduler.util;



public class Logger{
	

    public static enum DebugLevel { zero,one,two,three,four 
                                   };

    private static DebugLevel debugLevel;

	/**
	*@param levelIn
	*@Return none
	*/
    public static void setDebugValue (int levelIn) {
	switch (levelIn) {
	case 0: debugLevel = DebugLevel.zero;break;
	case 1: debugLevel = DebugLevel.one;break;
	case 2: debugLevel = DebugLevel.two;break;
	case 3: debugLevel = DebugLevel.three;break;
	case 4: debugLevel = DebugLevel.four; break;
	}
    }

    public static void setDebugValue (DebugLevel levelIn) {	
    	debugLevel = levelIn;
    }

    // @return None
    public static void writeMessage (String     message  ,
                                     DebugLevel levelIn ) {
	if (levelIn == debugLevel)
	    System.out.println(message);
    }
    
    public static DebugLevel getDebugValue(){
    	return debugLevel;
    }

    public String toString() {
	return "Debug Level is " + debugLevel;
    }
}

