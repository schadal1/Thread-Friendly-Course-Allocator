package registrationScheduler.util;

public class ObjectPool {

	private static ObjectPool UniquePool;
	private Course A,B,C,D,E,F,G;
	private static Student[] StudentList;
	private ObjectPool()
	{
		setA(new Course(60,"A"));
		setB(new Course(60,"B"));
		setC(new Course(60,"C"));
		setD(new Course(60,"D"));
		setE(new Course(60,"E"));
		setF(new Course(60,"F"));
		setG(new Course(60,"G"));	
		StudentList=new Student[100];
		
	}	
	public static ObjectPool getInstance()
	{
		if(UniquePool==null)
		{
			UniquePool=new ObjectPool();
		}
		return UniquePool;
	}
	public synchronized Student addObject()
	{
		StudentList[Student.studentCount]=new Student();
		return StudentList[Student.studentCount];
	}
	/**
	*@param String
	*@Return none
	*/
	public void borrowObject(String SubName)
	{
		try {
		switch (SubName)//(TempCourse.getCourseName()) //TempCourse.getCourseName()
		{
			case "A":
				
				if(A.getStatus()==1)
				{
					A.setStatus(0);
					int temp=A.getNoOfSeats();
					A.setNoOfSeats(--temp);					
					A.setStatus(1);
					//A.notify();
				}
				else
				{					
						//A.wait(0);
						borrowObject("A");
				}
			break;
			case "B":
				if(B.getStatus()==1)
				{
					B.setStatus(0);
					int temp=B.getNoOfSeats();
					B.setNoOfSeats(--temp);					
					B.setStatus(1);
					//B.notify();
					
				}
				else
				{
					//B.wait();
					borrowObject("B");
				}
				break;
			case "C":
				if(C.getStatus()==1)					
				{
					C.setStatus(0);
					int temp=C.getNoOfSeats();
					C.setNoOfSeats(--temp);					
					C.setStatus(1);
					//C.notify();
				}
				else
				{
					//C.wait();
					borrowObject("C");
				}
			break;
			case "D":
				if(D.getStatus()==1)
				{
					D.setStatus(0);
					int temp=D.getNoOfSeats();
					D.setNoOfSeats(--temp);					
					D.setStatus(1);
					//D.notify();
				}
				else
				{
					//D.wait();
					borrowObject("D");
				}
				break;
			case "E":
				if(E.getStatus()==1)
				{
					E.setStatus(0);
					int temp=E.getNoOfSeats();
					E.setNoOfSeats(--temp);					
					E.setStatus(1);
					//E.notify();
					
				}
				else
				{
					//E.wait();
					borrowObject("E");
				}
			break;
			case "F":
				if(F.getStatus()==1)
				{
					F.setStatus(0);
					int temp=F.getNoOfSeats();
					F.setNoOfSeats(--temp);					
					F.setStatus(1);
					//F.notify();
				}
				else
				{
					//F.wait();
					borrowObject("F");
				}
				break;
			case "G":
				if(G.getStatus()==1)
				{
					G.setStatus(0);
					int temp=G.getNoOfSeats();
					G.setNoOfSeats(--temp);					
					G.setStatus(1);
					//G.notify();
				}
				else
				{
					//G.wait();
					borrowObject("G");
				}
				break;				
			default:
			break;
			
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void invalidate(Course TempCourse)
	{
		
	}
	public  Course getD() {
		return D;
	}
	public  void setD(Course d) {
		D = d;
	}
	public  Course getG() {
		return G;
	}
	public  void setG(Course g) {
		G = g;
	}
	public  Course getA() {
		return A;
	}
	public  void setA(Course a) {
		A = a;
	}
	public  Course getB() {
		return B;
	}
	public  void setB(Course b) {
		B = b;
	}
	public  Course getE() {
		return E;
	}
	public  void setE(Course e) {
		E = e;
	}
	public  Course getF() {
		return F;
	}
	public  void setF(Course f) {
		F = f;
	}
	public  Course getC() {
		return C;
	}
	public  void setC(Course c) {
		C = c;
	}
	public  Student[] getStudentList() {
		return StudentList;
	}
	public  void setStudentList(Student[] studentList) {
		StudentList = studentList;
	}
	

}
