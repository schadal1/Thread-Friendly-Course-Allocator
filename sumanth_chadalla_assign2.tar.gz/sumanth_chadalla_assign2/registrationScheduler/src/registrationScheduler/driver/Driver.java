
package registrationScheduler.driver;

import registrationScheduler.util.Course;
import registrationScheduler.util.CourseAssignor;
import registrationScheduler.util.FileProcessor;
import registrationScheduler.util.Logger;
import registrationScheduler.util.ObjectPool;
import registrationScheduler.util.Scheduler;
import registrationScheduler.util.Student;

import registrationScheduler.store.StdoutDisplayInterface;
import registrationScheduler.store.FileDisplayInterface;
import registrationScheduler.store.Results;
import registrationScheduler.threadMgmt.CreateWorkers;
import registrationScheduler.threadMgmt.WorkerThread;


import java.io.FileNotFoundException;
import java.io.IOException;

public class Driver {

	public static void main(String[] args) throws NumberFormatException, InterruptedException, FileNotFoundException,IOException 
	{
		if(args.length!=4)
		{
			System.out.println("Wrong No of Command Line Arguments,Please enter Correct number of Arguments ");
		}
		else
		{	
			
			Logger.setDebugValue(Integer.parseInt(args[3]));
			FileProcessor Fp= FileProcessor.getInstance(args[0],args[1]);
			//Results resultsObj=new Results();
			StdoutDisplayInterface sd = new Results();
			FileDisplayInterface fd = new Results();
			CreateWorkers ThreadCreator =new CreateWorkers(Fp,sd,fd);
			ThreadCreator.startWorkers(Integer.parseInt(args[2]));			
			sd.writeSchedulesToScreen();
			fd.writeSchedulesToFile(args[1]);
			
		}			
	}
	
}
