
package registrationScheduler.threadMgmt;

import registrationScheduler.util.Course;
import registrationScheduler.util.CourseAssignor;
import registrationScheduler.util.FileProcessor;
import registrationScheduler.util.Logger;
import registrationScheduler.util.ObjectPool;
import registrationScheduler.util.Scheduler;
import registrationScheduler.util.Student;

import registrationScheduler.store.StdoutDisplayInterface;
import registrationScheduler.store.FileDisplayInterface;
import registrationScheduler.store.Results;
import registrationScheduler.threadMgmt.CreateWorkers;

public class WorkerThread implements Runnable {
	private FileProcessor Fp;
	private StdoutDisplayInterface Rs;
	private Scheduler scheduler;
	private Student s;
	private FileDisplayInterface fd;
	public WorkerThread(FileProcessor FpIn,StdoutDisplayInterface RsIn,FileDisplayInterface fdIn)
	{
		Fp=FpIn;
		Rs=RsIn;
		fd=fdIn;
		scheduler = new Scheduler();
		
		if(Logger.getDebugValue().equals(Logger.DebugLevel.four)){			
			Logger.writeMessage("WorkerThread Constructor invoked",Logger.DebugLevel.four );
		}
		
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		while(Fp.hasNextLine())
		{			
			s=scheduler.CreateStudent();
			scheduler.AssignVal(s,Fp.getLine());
			scheduler.AssignCourse(s);	
			Rs.setResults(""+s.getName()+" "+s.getAssignedCourse(0)+" "+s.getAssignedCourse(1)+" "+s.getAssignedCourse(2)+" "+s.getAssignedCourse(3)+" "+s.getAssignedCourse(4)+" "+s.getTotalPref());
			fd.setResults(""+s.getName()+" "+s.getAssignedCourse(0)+" "+s.getAssignedCourse(1)+" "+s.getAssignedCourse(2)+" "+s.getAssignedCourse(3)+" "+s.getAssignedCourse(4)+" "+s.getTotalPref());

			
	}

}
}                                                                 