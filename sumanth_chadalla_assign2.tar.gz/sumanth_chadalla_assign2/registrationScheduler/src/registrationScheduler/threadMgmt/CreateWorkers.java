
package registrationScheduler.threadMgmt;

import registrationScheduler.util.Course;
import registrationScheduler.util.CourseAssignor;
import registrationScheduler.util.FileProcessor;
import registrationScheduler.util.Logger;
import registrationScheduler.util.ObjectPool;
import registrationScheduler.util.Scheduler;
import registrationScheduler.util.Student;

import registrationScheduler.store.StdoutDisplayInterface;
import registrationScheduler.store.FileDisplayInterface;
import registrationScheduler.store.Results;
import registrationScheduler.threadMgmt.CreateWorkers;
import registrationScheduler.threadMgmt.WorkerThread;


public class CreateWorkers{
	private Thread[] myThreads;
	private FileProcessor fp;
	private StdoutDisplayInterface rs;
	private FileDisplayInterface fd;
	public CreateWorkers(FileProcessor FpIN,StdoutDisplayInterface RsIN,FileDisplayInterface fdIn)
	{
		fp=FpIN;
		rs=RsIN;
		fd=fdIn;
		if(Logger.getDebugValue().equals(Logger.DebugLevel.four)){			
			Logger.writeMessage("CreateWorkers Constructor invoked",Logger.DebugLevel.four );
		}	
		
	}
	public void startWorkers(int NUM_THREADS) throws InterruptedException
	{
		
		WorkerThread w;
		myThreads=new Thread[NUM_THREADS];
		
		for(int i=0;i<NUM_THREADS;i++)
		{
			if(Logger.getDebugValue().equals(Logger.DebugLevel.three)){			
				Logger.writeMessage("Thread"+i+" is running",Logger.DebugLevel.three );
			}
			w=new WorkerThread(fp,rs,fd);
			myThreads[i] = new Thread(w);
			myThreads[i].start();			
			Thread.sleep(50);			
		}
		try {
		for(int i=0;i<NUM_THREADS;i++)
		{
			myThreads[i].join();			
		}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*w=new WorkerThread(fp,rs);
		myThreads[0]=new Thread(w);
		myThreads[0].run();*/
	}
}
