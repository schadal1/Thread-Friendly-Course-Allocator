
package registrationScheduler.store;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import registrationScheduler.util.Course;
import registrationScheduler.util.CourseAssignor;
import registrationScheduler.util.FileProcessor;
import registrationScheduler.util.Logger;
import registrationScheduler.util.ObjectPool;
import registrationScheduler.util.Scheduler;
import registrationScheduler.util.Student;

import registrationScheduler.store.StdoutDisplayInterface;
import registrationScheduler.store.FileDisplayInterface;
import registrationScheduler.store.Results;
import registrationScheduler.threadMgmt.CreateWorkers;
import registrationScheduler.threadMgmt.WorkerThread;

public class Results implements StdoutDisplayInterface, FileDisplayInterface{

	protected ArrayList<String> store;
	double totalavg=0.0;
	public Results()
	{
		store= new ArrayList<String>();
	}
	@Override
	public void writeSchedulesToScreen() {	
		for(String value : store ){
			String[] col = value.split(" ");
			if(Logger.getDebugValue().equals(Logger.DebugLevel.one)){			
				Logger.writeMessage(value,Logger.DebugLevel.one );
			}
			if(Logger.getDebugValue().equals(Logger.DebugLevel.two)){			
				Logger.writeMessage(value,Logger.DebugLevel.two );
			}
			
			average(col[6]);			
		}
		if(Logger.getDebugValue().equals(Logger.DebugLevel.zero)){			
			Logger.writeMessage("\nThe average preference is "+totalavg/80,Logger.getDebugValue());
		}
		if(Logger.getDebugValue().equals(Logger.DebugLevel.one)){			
			Logger.writeMessage("\nThe average preference is "+totalavg/80,Logger.DebugLevel.one );
		}
		
		
		
	}
	

	@Override
	public void writeSchedulesToFile(String filename) throws FileNotFoundException {
		
		FileOutputStream fo = new FileOutputStream(new File(filename));
			PrintWriter pw = new PrintWriter(fo);
			String[] col;
			for(String value: store){
				pw.println(value);
				col = value.split(" ");			
				average(col[6]);

			}
			
			pw.println("\nThe average preference is "+totalavg/80);
			pw.close();	
			try {
				fo.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
				
	}
	
	public void setResults(String results) {
		store.add(results);		
	}
	
	public void average(String value){
		double avg=Double.parseDouble(value);
		totalavg+=avg;
		
	}
	
}

	