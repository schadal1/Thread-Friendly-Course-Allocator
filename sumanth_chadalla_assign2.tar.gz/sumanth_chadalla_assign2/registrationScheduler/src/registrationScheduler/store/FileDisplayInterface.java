package registrationScheduler.store;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface FileDisplayInterface {
	//Write to file 
	public void writeSchedulesToFile(String output) throws FileNotFoundException, IOException;
	//this is to store the results in the data structure
	public void setResults(String string);
}
