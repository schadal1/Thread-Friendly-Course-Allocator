
package registrationScheduler.store;

public interface StdoutDisplayInterface {
	//this is to write to screen
	public void writeSchedulesToScreen();
	//This is used to store into data structure
	public void setResults(String string);

}
